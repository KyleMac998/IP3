<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tutorials</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet"
          type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/landing-page.min.css" rel="stylesheet">


</head>

<body>

<?php

// test 55.8642,-4.2518

//https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=AIzaSyArOzjdrSzwoqdTDg4ce7HNTlsiW_XxUwk


$location = htmlentities($_POST['location']);

$location = str_replace(' ', '+', $location);


$google_api = 'https://maps.googleapis.com/maps/api/geocode/json?address=' . $location . '&key=AIzaSyArOzjdrSzwoqdTDg4ce7HNTlsiW_XxUwk';

$location_data = json_decode(file_get_contents($google_api));

$coordinates = $location_data->results[0]->geometry->location;

$coordinates = $coordinates->lat . ',' . $coordinates->lng;

$searched_location = $location_data->results[0]
    ->formatted_address;


$api_url = 'https://api.darksky.net/forecast/d5443fed198ba7aee4ac82d2b12aba5b/' . $coordinates;


$forecast = json_decode(file_get_contents($api_url));

// api stuff, remove "//"// to see variable names on webpage
//echo '<pre>';
//print_r($forecast);
//echo '</pre>';

// current conditions
$temp_current = round($forecast->currently->temperature);
$summary_current = $forecast->currently->summary;
$windSpeed_current = round($forecast->currently->windSpeed);
$humidity_current = $forecast->currently->humidity * 100;

//functions
//converting to Celcuis
function celcius($temp)
{
    return round(($temp - 32) * .5556);
}

// converting mph to KPH

function kph($speed)
{
    return (($speed) * 1.6);
}

//finding correct weather icons
function find_icon($icon)
{
    if ($icon === 'clear-day') {
        $weather_icon = '<i class="wi wi-day-sunny"></i>';
        return $weather_icon;
    } elseif ($icon === 'clear-night') {
        $weather_icon = '<i class="wi wi-night-clear"></i>';
        return $weather_icon;
    } elseif ($icon === 'rain') {
        $weather_icon = '<i class="wi wi-rain"></i>';
        return $weather_icon;
    } elseif ($icon === 'snow') {
        $weather_icon = '<i class="wi wi-snowflake-cold"></i>';
        return $weather_icon;
    } elseif ($icon === 'sleet') {
        $weather_icon = '<i class="wi wi-sleet"></i>';
        return $weather_icon;
    } elseif ($icon === 'wind') {
        $weather_icon = '<i class="wi wi-strong-wind"></i>';
        return $weather_icon;
    } elseif ($icon === 'fog') {
        $weather_icon = '<i class="wi wi-fog"></i>';
        return $weather_icon;
    } elseif ($icon === 'cloudy') {
        $weather_icon = '<i class="wi wi-cloudy"></i>';
        return $weather_icon;
    } elseif ($icon === 'partly-cloudy-day') {
        $weather_icon = '<i class="wi wi-day-cloudy"></i>';
        return $weather_icon;
    } elseif ($icon === 'partly-cloudy-night') {
        $weather_icon = '<i class="wi wi-night-alt-cloudy"></i>';
        return $weather_icon;
    } else {
        $weather_icon = 'i class="wi wi-na"></i>';
        return $weather_icon;
    }
}


//setting time zone based on location of searcher
date_default_timezone_set($forecast->timezone)


?>

<!-- Navigation -->
<nav class="navbar navbar-light bg-light static-top">
    <div class="container">
        <a class="navbar-brand" href="#">Overview</a>
        <a class="btn btn-primary" href="#">About Us</a>
        <a class="btn btn-primary" href="#">Weather Page</a>
        <a class="btn btn-primary" href="#">EarthQuake Page</a>
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Visuals Page
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="#">V1</a>
                <a class="dropdown-item" href="#">V2 </a>
                <a class="dropdown-item" href="#">v3</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Tutorial Page
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="#">TP1</a>
                <a class="dropdown-item" href="#">TP2 </a>
                <a class="dropdown-item" href="#">TP3</a>
            </div>
        </div>
        <a class="btn btn-primary" href="#">F.A.Q</a>
    </div>
</nav>


<?php require 'partials/header.php' ?>
<?php require 'partials/main.php' ?>
<?php require 'partials/footer.php' ?>

<footer class="footer bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
                <ul class="list-inline mb-2">
                    <li class="list-inline-item">
                        <a href="#">About</a>
                    </li>
                    <li class="list-inline-item">&sdot;</li>
                    <li class="list-inline-item">
                        <a href="#">Contact</a>
                    </li>
                    <li class="list-inline-item">&sdot;</li>
                    <li class="list-inline-item">
                        <a href="#">Terms of Use</a>
                    </li>
                    <li class="list-inline-item">&sdot;</li>
                    <li class="list-inline-item">
                        <a href="#">Privacy Policy</a>
                    </li>
                </ul>
                <p class="text-muted small mb-4 mb-lg-0">&copy; Your Website 2019. All Rights Reserved.</p>
            </div>
            <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item mr-3">
                        <a href="#">
                            <i class="fab fa-facebook fa-2x fa-fw"></i>
                        </a>
                    </li>
                    <li class="list-inline-item mr-3">
                        <a href="#">
                            <i class="fab fa-twitter-square fa-2x fa-fw"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#">
                            <i class="fab fa-instagram fa-2x fa-fw"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


</body>
</html>